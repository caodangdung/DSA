#include"UnrolledLinkedList.h"

void UnrolledLinkedList::add(int val) {
	// TODO
	if (head == NULL)
	{
		Node* newNode = new Node(nodeSize);
		head = newNode;
		head->add(val);
		tail = head;
		numOfNodes++;
		size++;
	}
	else if (tail->numElements < nodeSize)
	{
		tail->add(val);
		size++;
	}
	else
	{
		Node* pTemp = tail;
		Node* newNode = new Node(nodeSize);
		int halfNodeSize = pTemp->getHalfNodeSize();
		for (int i = halfNodeSize; i < nodeSize; i++)
		{
			newNode->add(pTemp->elements[i]);
		}
		newNode->add(val);
		pTemp->next = newNode;
		newNode->prev = pTemp;
		tail = newNode;
		size++;
		numOfNodes++;
		while (pTemp->numElements > pTemp->getHalfNodeSize())
		{
			pTemp->removeAt(pTemp->getHalfNodeSize());
		}
		pTemp = pTemp->next;
	}


}

int UnrolledLinkedList::getAt(int pos) {
	if (pos < 0 || pos >= size)
	{
		throw "IndexOutOfBoundsException"; // check whether pos is valid or not
	}
	// TODO
	else
	{
		Node* currentNode = head;
		int currentPos = 0;
		while ((currentNode->numElements - 1 + currentPos) < pos)
		{
			currentPos = currentPos + currentNode->numElements;
			currentNode = currentNode->next;
		}
		int pPos = pos - currentPos;
		return currentNode->elements[pPos];
	}
}

void UnrolledLinkedList::setAt(int pos, int val) {
	if (pos < 0 || pos >= size)
	{
		throw "IndexOutOfBoundsException";
	}// check whether pos is valid or not
	// TODO
	else
	{
		Node* currentNode = head;
		int currentPos = 0;
		while ((currentNode->numElements - 1 + currentPos) < pos)
		{
			currentPos = currentPos + currentNode->numElements;
			currentNode = currentNode->next;
		}
		int pPos = pos - currentPos;
		currentNode->elements[pPos] = val;
	}
}

void UnrolledLinkedList::insertAt(int pos, int val) {
	if (pos < 0 || pos > size)
	{
		throw "IndexOutOfBoundsException"; // check whether pos is valid or not	
	}
	// TODO
	else
	{
		if (pos == size)
		{
			add(val);
		}
		else
		{
			Node* currentNode = head;
			int currentPos = 0;
			while ((currentNode->numElements - 1 + currentPos) < pos)
			{
				currentPos = currentPos + currentNode->numElements;
				currentNode = currentNode->next;
			}
			int pPos = pos - currentPos;
			if (!currentNode->isFull())
			{
				currentNode->insertAt(pPos, val);
				size++;
			}
			else
			{
				Node* newNode = new Node(nodeSize);
				int halfNodeSize = currentNode->getHalfNodeSize();
				if (currentNode->next == NULL)
				{
					int count = 0;
					if (pPos <= halfNodeSize - 1)
					{
						for (int i = halfNodeSize - 1; i < nodeSize; i++)
						{
							newNode->elements[count] = currentNode->elements[i];
							newNode->numElements++;
							count++;
						}
						while (currentNode->numElements > halfNodeSize - 1)
						{
							currentNode->removeAt(halfNodeSize - 1);
						}
						currentNode->next = newNode;
						tail = newNode;
						tail->next = NULL;
						numOfNodes++;

						currentNode->insertAt(pPos, val);
						size++;
					}
					else
					{
						for (int i = halfNodeSize; i < nodeSize; i++)
						{
							newNode->elements[count] = currentNode->elements[i];
							newNode->numElements++;
							count++;
						}
						while (currentNode->numElements > halfNodeSize)
						{
							currentNode->removeAt(halfNodeSize);
						}
						currentNode->next = newNode;
						tail = newNode;
						tail->next = NULL;
						numOfNodes++;

						Node* currentNode = head;
						int currentPos = 0;
						while ((currentNode->numElements - 1 + currentPos) < pos)
						{
							currentPos = currentPos + currentNode->numElements;
							currentNode = currentNode->next;
						}
						int pPos = pos - currentPos;
						currentNode->insertAt(pPos, val);
						size++;
					}
				}
				else
				{
					Node* pNext = currentNode->next;
					int count = 0;
					if (pPos <= halfNodeSize - 1)
					{
						for (int i = halfNodeSize - 1; i < nodeSize; i++)
						{
							newNode->elements[count] = currentNode->elements[i];
							newNode->numElements++;
							count++;
						}
						while (currentNode->numElements > halfNodeSize - 1)
						{
							currentNode->removeAt(halfNodeSize - 1);
						}
						currentNode->next = newNode;
						newNode->next = pNext;
						numOfNodes++;

						currentNode->insertAt(pPos, val);
						size++;
					}
					else
					{
						for (int i = halfNodeSize; i < nodeSize; i++)
						{
							newNode->elements[count] = currentNode->elements[i];
							newNode->numElements++;
							count++;
						}
						while (currentNode->numElements > halfNodeSize)
						{
							currentNode->removeAt(halfNodeSize);
						}
						currentNode->next = newNode;
						newNode->next = pNext;
						numOfNodes++;

						Node* currentNode = head;
						int currentPos = 0;
						while ((currentNode->numElements - 1 + currentPos) < pos)
						{
							currentPos = currentPos + currentNode->numElements;
							currentNode = currentNode->next;
						}
						int pPos = pos - currentPos;
						currentNode->insertAt(pPos, val);
						size++;
					}
				}
			}
		}
	}
}

void UnrolledLinkedList::deleteAt(int pos)
{
	if (pos < 0 || pos >= size)
	{
		throw "indexoutofboundsexception";// check whether pos is valid or not
	}
	// todo
	else
	{
		Node* currentNode = head;
		int currentPos = 0;
		while ((currentNode->numElements - 1 + currentPos) < pos)
		{
			currentPos = currentPos + currentNode->numElements;
			currentNode = currentNode->next;
		}
		int pPos = pos - currentPos;
		currentNode->removeAt(pPos);
		size--;
		int halfNodeSize = currentNode->getHalfNodeSize();
		if (currentNode == tail)
		{
			if (currentNode->numElements < halfNodeSize)
			{
				if (currentNode->prev->numElements > halfNodeSize)
				{
					currentNode->elements[0] = currentNode->prev->elements[currentNode->prev->numElements - 1];

				}
				else
				{
					Node* pPre = currentNode->prev;
					for (int i = 0; i < currentNode->numElements; i++)
					{
						currentNode->prev->elements[currentNode->prev->numElements] = currentNode->elements[i];
						currentNode->prev->numElements++;
					}
					while (currentNode->numElements > 0)
					{
						currentNode->removeAt(0);
					}
					tail = pPre;
					tail->next = NULL;
					numOfNodes--;
				}
			}
		}
		else
		{
			if (currentNode->numElements < halfNodeSize)
			{
				if (currentNode->next == NULL)
				{
					return;
				}
				else if (currentNode->next != NULL)
				{
					if (currentNode->next->numElements > halfNodeSize)
					{
						currentNode->elements[currentNode->numElements] = currentNode->next->elements[0];
						currentNode->numElements++;
						currentNode->next->removeAt(0);
					}
					else
					{
						Node* pNext = currentNode->next;
						for (int i = 0; i < currentNode->next->numElements; i++)
						{
							currentNode->elements[currentNode->numElements] = currentNode->next->elements[i];
							currentNode->numElements++;
						}
						while (currentNode->next->numElements > 0)
						{
							currentNode->next->removeAt(0);
						}
						if (pNext == tail)
						{
							currentNode->next = pNext->next;
							tail = currentNode;
							tail->next = NULL;
						}
						else
						{
							currentNode->next = pNext->next;
							currentNode = pNext->prev;
						}
						numOfNodes--;
					}
				}
			}
		}

	}
}

int UnrolledLinkedList::firstIndexOf(int val) {
	// TODO
	Node* pTemp = head;
	if (!contains(val))
	{
		return -1;
	}
	else
	{
		int position = NULL;
		int count = NULL;
		bool check = false;
		while (pTemp != NULL)
		{
			for (int i = 0; i < pTemp->numElements; i++)
			{
				if (pTemp->elements[i] == val)
				{
					position = count;
					check = true;
					break;
				}
				else
				{
					count++;
				}
			}
			if (check)
				break;
			pTemp = pTemp->next;
		}
		return position;
	}

}

int UnrolledLinkedList::lastIndexOf(int val) {
	// TODO

	if (!contains(val))
	{
		return -1;
	}
	else
	{
		reverse();
		Node* pTemp = head;
		int position = NULL;
		int count = NULL;
		bool check = false;
		while (pTemp != NULL)
		{
			for (int i = 0; i < pTemp->numElements; i++)
			{
				if (pTemp->elements[i] == val)
				{
					position = size - count - 1;
					check = true;
					break;
				}
				else
				{
					count++;
				}
			}
			if (check)
				break;
			pTemp = pTemp->next;
		}
		reverse();
		return position;
	}

}

bool UnrolledLinkedList::contains(int val) {
	// TODO
	Node* pTemp = head;
	if (pTemp == NULL)
	{
		return false;
	}
	bool check = false;
	while (pTemp != NULL)
	{
		for (int i = 0; i < pTemp->numElements; i++)
		{
			if (pTemp->elements[i] == val)
			{
				check = true;
				break;
			}
		}
		pTemp = pTemp->next;
	}
	return check;
}

void UnrolledLinkedList::reverse() {
	// TODO
	Node *Pre = 0;
	while (head != NULL)
	{
		Node *pNext = head->next;
		head->next = Pre;
		Pre = head;
		head = pNext;
	}
	head = Pre;
	tail = head;
	while (tail->next != NULL)
		tail = tail->next;
	Node* pTemp = head;
	while (pTemp != NULL)
	{
		pTemp->reverse();
		pTemp = pTemp->next;
	}
}

int* UnrolledLinkedList::toArray() {
	// TODO
	int * array = new int[size];
	int count = 0;
	for (Node* i = head; i != NULL; i = i->next)
	{
		for (int j = 0; j < i->numElements; j++)
		{
			array[count] = i->elements[j];
			count++;
		}
	}
	return array;
}