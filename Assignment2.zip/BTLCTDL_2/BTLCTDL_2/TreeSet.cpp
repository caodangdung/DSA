/* Copyright (C) 2018
* Course: CO2003
* Author: Rang Nguyen
* Ho Chi Minh City University of Technology
*/

#include "TreeSet.h"

TreeSet::TreeSet()
{
	root = NULL;
	count = 0;
}

TreeSet::~TreeSet()
{
	clear();
}

void TreeSet::clearRec(AVLNode* root) {
	if (root != NULL) {
		clearRec(root->left);
		clearRec(root->right);
		delete root;
	}
}

void TreeSet::clear() {
	clearRec(root);
	root = NULL;
	count = 0;
}


int TreeSet::max(int value1, int value2)
{
	if (value1 > value2)
		return value1;
	else
		return value2;
}

int TreeSet::getHeight(AVLNode *&root)
{
	if (root == NULL)
		return 0;
	else
	{
		return root->balance;
	}
}

AVLNode *TreeSet::rotateLL(AVLNode *&root)
{
	AVLNode *pTemp = root->right;
	root->right = pTemp->left;
	pTemp->left = root;
	root->balance = max(getHeight(root->left), getHeight(root->right)) + 1;
	pTemp->balance = max(getHeight(pTemp->right), root->balance) + 1;
	return pTemp;
}

AVLNode *TreeSet::rotateRR(AVLNode *&root)
{
	AVLNode *pTemp = root->left;
	root->left = pTemp->right;
	pTemp->right = root;
	root->balance = max(getHeight(root->left), getHeight(root->right)) + 1;
	pTemp->balance = max(getHeight(pTemp->left), root->balance) + 1;
	return pTemp;
}

AVLNode *TreeSet::rotateLR(AVLNode *&root)
{
	root->left = rotateLL(root->left);
	return rotateRR(root);
}

AVLNode *TreeSet::rotateRL(AVLNode *&root)
{
	root->right = rotateRR(root->right);
	return rotateLL(root);
}

AVLNode *TreeSet::addNode(AVLNode *&root, int value)
{
	if (root == NULL)
		return (root = new AVLNode(value));
	else if (value < root->key)
		root->left = addNode(root->left, value);
	else
		root->right = addNode(root->right, value);

	root->balance = max(getHeight(root->left), getHeight(root->right)) + 1;
	if (getHeight(root->left) - getHeight(root->right) == 2)
	{
		if (value < root->left->key)
			root = rotateRR(root);
		else
			root = rotateLR(root);
	}
	else if (getHeight(root->right) - getHeight(root->left) == 2)
	{
		if (value < root->right->key)
			root = rotateRL(root);
		else
			root = rotateLL(root);
	}
	return root;
}

AVLNode *TreeSet::removeNode(AVLNode *&root, int value)
{
	if (root == NULL)
		return NULL;
	if (value == root->key)
	{
		if (root->right == NULL)
		{
			AVLNode *pTemp = root;
			root = root->left;
			delete(pTemp);
			return root;
		}
		else
		{
			AVLNode *pTemp = root->right;
			while (pTemp->left)
				pTemp = pTemp->left;

			root->key = pTemp->key;

			root->right = removeNode(root->right, pTemp->key);
		}
	}
	else if (value < root->key)
		root->left = removeNode(root->left, value);
	else
		root->right = removeNode(root->right, value);

	root->balance = max(getHeight(root->left), getHeight(root->right)) + 1;
	if (getHeight(root->right) - getHeight(root->left) == 2)
	{
		if (getHeight(root->right->right) >= getHeight(root->right->left))
			root = rotateLL(root);
		else
			root = rotateRL(root);
	}
	else if (getHeight(root->left) - getHeight(root->right) == 2)
	{
		if (getHeight(root->left->left) >= getHeight(root->left->right))
			root = rotateRR(root);
		else
			root = rotateLR(root);
	}
	return root;
}

int TreeSet::add(int val) {
	// TODO
	if (val < 0)
		return 0;
	else
	{
		if (count == 0)
		{
			root = new AVLNode(val);
			count++;
		}
		else if (contains(val))
			return 0;
		else
		{
			addNode(root, val);
			count++;
			return 1;
		}
	}

}

bool TreeSet::contains(int val) {
	// TODO
	AVLNode *pTemp = root;
	while (pTemp != NULL)
	{
		if (pTemp->key > val)
			pTemp = pTemp->left;
		else if (pTemp->key < val)
			pTemp = pTemp->right;
		else
		{
			return true;
			break;
		}
	}
	return false;
}

void TreeSet::copy(const TreeSet& set) {
	// TODO

	AVLNode *pre;
	AVLNode *current = set.root;
	while (current != NULL)
	{
		if (current->left == NULL)
		{
			this->add(current->key);
			current = current->right;
		}
		else
		{
			pre = current->left;
			while (pre->right && pre->right != current)
			{
				pre = pre->right;
			}
			if (pre->right == NULL)
			{
				pre->right = current;
				current = current->left;
			}
			else
			{
				pre->right = NULL;
				this->add(current->key);
				current = current->right;
			}
		}
	}

}

int TreeSet::first() {
	if (root == NULL) {
		throw "NoSuchElementException";
	}
	// TODO
	else
	{
		//return first(root);
		AVLNode* pTemp = root;
		while (true)
		{
			if (pTemp->left == NULL)
			{
				return pTemp->key;
				break;
			}
			pTemp = pTemp->left;
		}
	}
}

int TreeSet::last() {
	if (root == NULL) {
		throw "NoSuchElementException";
	}
	// TODO
	else
	{
		AVLNode* pTemp = root;
		while (true)
		{
			if (pTemp->right == NULL)
			{
				return pTemp->key;
				break;
			}
			pTemp = pTemp->right;
		}
	}

}

int TreeSet::higher(int val) {
	// TODO

	int value = -1;
	AVLNode *pTemp = root;
	while (pTemp != NULL)
	{
		if (pTemp->key > val)
		{
			value = pTemp->key;
			pTemp = pTemp->left;
		}
		else
		{
			pTemp = pTemp->right;
		}
	}
	return value;

}

int TreeSet::lower(int val) {
	// TODO
	int value = -1;
	AVLNode *pTemp = root;
	while (pTemp != NULL)
	{
		if (pTemp->key < val)
		{
			value = pTemp->key;
			pTemp = pTemp->right;
		}
		else
		{
			pTemp = pTemp->left;
		}
	}
	return value;

}

int TreeSet::remove(int val) {
	// TODO

	if (!contains(val))
	{
		return false;
	}
	else
	{
		removeNode(root, val);
		count--;
		return true;
	}
}

TreeSet* TreeSet::subSet(int fromVal, int toVal) {
	// TODO
	TreeSet *sub = new TreeSet;
	AVLNode *pre;
	AVLNode *current = root;
	while (current != NULL)
	{
		while (current != NULL)
		{
			if (current->left == NULL)
			{
				if ((current->key > fromVal || current->key == fromVal) && current->key < toVal)
					sub->add(current->key);
				current = current->right;
			}
			else
			{
				pre = current->left;
				while (pre->right && pre->right != current)
				{
					pre = pre->right;
				}
				if (pre->right == NULL)
				{
					pre->right = current;
					current = current->left;
				}
				else
				{
					pre->right = NULL;
					if ((current->key > fromVal || current->key == fromVal) && current->key < toVal)
						sub->add(current->key);
					current = current->right;
				}
			}
		}
	}
	return sub;
}

int TreeSet::size() {
	// TODO
	return count;
}

